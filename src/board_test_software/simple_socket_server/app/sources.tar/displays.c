#include "io.h"
#include "system.h"
#include "displays.h"

//
//	this function sends a string to be displayed on the five line graphics display
//	you may send any ascii character for display, the character code will be translated
//	by the display controller for display.  there are three special characters
//	interpreted by the display controller:
//		'\n' - shifts the display up one line and clears the bottom line of the display
//		'\r' - clears the bottom line of the display
//		'\b' - back spaces over the last character on the display
//
//	so typical usage would be putstr_gfx("\nHello world!");
//		
void putstr_gfx(char* str) {
	while(*str != '\0') {
		// wait if the fifo is almost full
		while(IORD_32DIRECT(DISPLAY_FIFO_IN_CSR_BASE, 0) > (DISPLAY_FIFO_IN_CSR_FIFO_DEPTH - 10));

		IOWR_32DIRECT(DISPLAY_FIFO_IN_BASE, 0, (COMMAND_GFX << COMMAND_OFST) | (alt_u8)(*str++));
	}
}

//
//	this function sends a string to be displayed on the two line character display
//	you may send any ascii character for display, the character code will be translated
//	by the character graphics controller for display.  there are three special characters
//	interpreted by the display controller:
//		'\n' - shifts the display up one line and clears the bottom line of the display
//		'\r' - clears the bottom line of the display
//		'\b' - back spaces over the last character on the display
//
//	so typical usage would be putstr_chr("\nHello world!");
//		
void putstr_chr(char* str) {
	while(*str != '\0') {
		// wait if the fifo is almost full
		while(IORD_32DIRECT(DISPLAY_FIFO_IN_CSR_BASE, 0) > (DISPLAY_FIFO_IN_CSR_FIFO_DEPTH - 10));

		IOWR_32DIRECT(DISPLAY_FIFO_IN_BASE, 0, (COMMAND_CHR << COMMAND_OFST) | (alt_u8)(*str++));
	}
}

//
//	this function sends a reset command to the display controller
//	
void reset_displays(void) {
	// wait if the fifo is almost full
	while(IORD_32DIRECT(DISPLAY_FIFO_IN_CSR_BASE, 0) > (DISPLAY_FIFO_IN_CSR_FIFO_DEPTH - 10));

	IOWR_32DIRECT(DISPLAY_FIFO_IN_BASE, 0, (COMMAND_NOP << COMMAND_OFST) | (0x0A55A55A));
}
