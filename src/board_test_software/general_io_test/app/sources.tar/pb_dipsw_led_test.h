#ifndef PB_DIPSW_LED_TEST_H_
#define PB_DIPSW_LED_TEST_H_

void test_pb(void);
void test_dipsw_and_leds(void);

#endif /*PB_DIPSW_LED_TEST_H_*/
