#include "system.h"
#include "alt_types.h"
#include "seven_seg.h"
#include "displays.h"
#include "io.h"

const alt_u8 digit_map[16] = {
		_0_DIGIT,
		_1_DIGIT,
		_2_DIGIT,
		_3_DIGIT,
		_4_DIGIT,
		_5_DIGIT,
		_6_DIGIT,
		_7_DIGIT,
		_8_DIGIT,
		_9_DIGIT,
		_A_DIGIT,
		_B_DIGIT,
		_C_DIGIT,
		_D_DIGIT,
		_E_DIGIT,
		_F_DIGIT
};

//
//	set_seven_seg_display()
//
//	alt_u32 new_value - the low 4 nibbles of this value are displayed on the seven segement digits
//	alt_u32 new_digit_enable - the low 4 bits of this value enable each digit on the seven segment display
//	alt_u32 new_dp_bits - the low 4 bits of this value control the dp associated with each digit
//	alt_u32 new_minus_bit - the lsb of this value controls the minus sign on the display
//
void set_seven_seg_display(alt_u32 new_value, alt_u32 new_digit_enable, alt_u32 new_dp_bits, alt_u32 new_minus_bit) {
	alt_u32 initial_context;
	
	initial_context = (new_value) & (DIGIT_3_VALUE_MASK | DIGIT_2_VALUE_MASK | DIGIT_1_VALUE_MASK | DIGIT_0_VALUE_MASK);
	initial_context |= (new_digit_enable << DIGIT_0_ENABLE_OFST) & (DIGIT_3_ENABLE_MASK | DIGIT_2_ENABLE_MASK | DIGIT_1_ENABLE_MASK | DIGIT_0_ENABLE_MASK);
	initial_context |= (new_dp_bits << DP_0_VALUE_OFST) & (DP_3_VALUE_MASK | DP_2_VALUE_MASK | DP_1_VALUE_MASK | DP_0_VALUE_MASK);
	initial_context |= (new_minus_bit << MINUS_OFST) & (MINUS_MASK);
	
	// wait if the fifo is almost full
	while(IORD_32DIRECT(DISPLAY_FIFO_IN_CSR_BASE, 0) > (DISPLAY_FIFO_IN_CSR_FIFO_DEPTH - 10));

	IOWR_32DIRECT(DISPLAY_FIFO_IN_BASE, 0, (COMMAND_7SEG << COMMAND_OFST) | (initial_context));
}
