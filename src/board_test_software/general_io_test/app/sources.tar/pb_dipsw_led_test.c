#include "stdio.h"
#include "system.h"
#include "altera_avalon_pio_regs.h"

void test_pb(void) {
	alt_u32 current_pb;
	
	current_pb = IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x0F;
	if(current_pb != 0x0F) {
		printf("ERROR: expected PB read of 0x0F but got 0x%02X\n", current_pb);
		return;
	}

	printf("Press and hold USER_PB0...\n");
	while(IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x01);
	printf("Release USER_PB0...\n");
	while(!(IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x01));

	printf("Press and hold USER_PB1...\n");
	while(IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x02);
	printf("Release USER_PB1...\n");
	while(!(IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x02));

	printf("Press and hold USER_PB2...\n");
	while(IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x04);
	printf("Release USER_PB2...\n");
	while(!(IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x04));

	printf("Press and hold USER_PB3...\n");
	while(IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x08);
	printf("Release USER_PB3...\n");
	while(!(IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x08));
	
	printf("PB tests passed...\n");
}

void test_dipsw_and_leds(void) {
	alt_u32 current_pb;

	printf("Now mirroring the USER_DIPSW settings over to the USER_LEDs...\n");
	printf("Current USER_DIPSW set as 0x%02X...\n", IORD_ALTERA_AVALON_PIO_DATA(USER_DIPSW_PIO_8IN_BASE) & 0xFF);
	printf("Press any USER_PB to exit test...\n");
	
	current_pb = IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x0F;
	while(current_pb == 0x0F) {
		IOWR_ALTERA_AVALON_PIO_DATA(USER_LED_PIO_8OUT_BASE, IORD_ALTERA_AVALON_PIO_DATA(USER_DIPSW_PIO_8IN_BASE));
		current_pb = IORD_ALTERA_AVALON_PIO_DATA(USER_PB_PIO_4IN_BASE) & 0x0F;
	}
	IOWR_ALTERA_AVALON_PIO_DATA(USER_LED_PIO_8OUT_BASE, 0xFF);
	printf("Exiting USER_DIPSW and USER_LED test...\n");
}
