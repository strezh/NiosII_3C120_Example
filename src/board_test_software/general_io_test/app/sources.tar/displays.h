#ifndef DISPLAYS_H_
#define DISPLAYS_H_

// these commands are used to communicate over the fifo with the display controller
#define COMMAND_MASK	(0xC0000000)
#define COMMAND_OFST	(30)
#define COMMAND_NOP		(0x00)
#define COMMAND_7SEG	(0x01)
#define COMMAND_CHR		(0x02)
#define COMMAND_GFX		(0x03)

void putstr_gfx(char* str);
void putstr_chr(char* str);
void reset_displays(void);

#endif /*DISPLAYS_H_*/
