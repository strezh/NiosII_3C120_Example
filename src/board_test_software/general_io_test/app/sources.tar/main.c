#include <stdio.h>
#include "io.h"
#include "alt_types.h"
#include "system.h"
#include "pb_dipsw_led_test.h"

#include "displays.h"
#include "seven_seg.h"

int main()
{
	int i;
	int j;
	
	printf("Hello from Nios II!\n");
	
	putstr_gfx("\n\n\n\n\nHello from Nios!");
	
	putstr_chr("\n\nHello from Nios!");

	set_seven_seg_display(
			0x4321,		// alt_u32 new_value, 
			0x0F,		// alt_u32 new_digit_enable, 
			0x0F,		//alt_u32 new_dp_bits, 
			0x01		//alt_u32 new_minus_bit
		);
	
//	reset_displays();
	
	test_pb();
	test_dipsw_and_leds();
	
	printf("\n");
	printf("Flash Dump, first 256 bytes...\n");
	printf("\n");
	for(i = 0 ; i < 16 ; i++) {
		for(j = 0 ; j < 16 ; j++) {
			printf("%02X ", *(alt_u8*)(CFI_FLASH_64M_BASE + (i * 16) + j));
		}
		printf("\n");
	}
	printf("\n");

	printf("\n");
	printf("Flash Dump, Ethernet option bits...\n");
	printf("\n");
	for(i = 0 ; i < 16 ; i++) {
		for(j = 0 ; j < 16 ; j++) {
			printf("%02X ", *(alt_u8*)(CFI_FLASH_64M_BASE + 0x03FC0000 + (i * 16) + j));
		}
		printf("\n");
	}
	printf("\n");

	printf("CPU Configuration ROM Dump:\n\n%s\n", (char*)(CPU_CONFIG_ROM_8K_BASE));
	
	printf("All tests complete...\n");
	
	return 0;
}
