#include "mem_test.h"

alt_u32 databus_walking_one_word(MEM_TEST_STRUCT *mem_test)
{
  volatile alt_u32 *current_ptr;
  alt_u32 count;
  alt_u32 word_pattern;
  alt_u32 mem_data;
  
  current_ptr = (alt_u32 *)(mem_test->base_address);
  count = 32;
  word_pattern = 0x00000001;
  
  do
  {
    *current_ptr++ = word_pattern;
    word_pattern = word_pattern << 1;
    count--;
  }while(count > 0);
  
  current_ptr = (alt_u32 *)(mem_test->base_address);
  count = 32;
  word_pattern = 0x00000001;
  
  do
  {
    mem_data = *current_ptr++;
    if(mem_data != word_pattern)
    {
      mem_test->result = 1;
      mem_test->failing_address = (alt_u32)(--current_ptr);
      mem_test->expected_data = word_pattern;
      mem_test->actual_data = mem_data;
      return 1;
    }
    word_pattern = word_pattern << 1;
    count--;
  }while(count > 0);
  
  mem_test->result = 0;
  return 0;
}
