#ifndef __MEM_TEST_H__

#define __MEM_TEST_H__

#include "alt_types.h"

typedef struct {
  alt_u32 base_address;
  alt_u32 span_in_bytes;
  alt_u32 result;
  alt_u32 failing_address;
  alt_u32 expected_data;
  alt_u32 actual_data;
}MEM_TEST_STRUCT;

#endif /* __MEM_TEST_H__ */
