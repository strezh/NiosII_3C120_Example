#include "mem_test.h"

alt_u32 addressbus_walking_zero_word(MEM_TEST_STRUCT *mem_test)
{
  volatile alt_u32 *current_ptr;
  alt_u32 temp;
  alt_u32 max_addr;
  alt_u32 mem_data;
  
  current_ptr = (alt_u32 *)(mem_test->base_address);
  max_addr = ((mem_test->span_in_bytes) - 1) >> 2;
  temp = max_addr & 0xFFFFFFFE;
  do
  {
    *(current_ptr + temp) = temp;
    temp = ((temp << 1) | 0x01) & (max_addr);
  }while(max_addr > temp);
  
  temp = max_addr & 0xFFFFFFFE;
  do
  {
    mem_data = *(current_ptr + temp);
    if(mem_data != temp)
    {
      mem_test->result = 1;
      mem_test->failing_address = (alt_u32)(current_ptr + temp);
      mem_test->expected_data = temp;
      mem_test->actual_data = mem_data;
      return 1;
    }
    temp = ((temp << 1) | 0x01) & (max_addr);
  }while(max_addr > temp);
  
  mem_test->result = 0;
  return 0;
}
