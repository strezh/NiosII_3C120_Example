#include "mem_test.h"

alt_u32 address_uniqueness_byte_word(MEM_TEST_STRUCT *mem_test)
{
  volatile alt_u8 *current_ptr_byte;
  volatile alt_u32 *current_ptr_word;
  alt_u32 count;
  alt_u32 word_pattern;
  alt_u32 temp;
  alt_u32 mem_data;
  
  current_ptr_byte = (alt_u8 *)(mem_test->base_address);
  count = (mem_test->span_in_bytes) >> 0;
  word_pattern = 0x33557799;
  
  do
  {
    *current_ptr_byte++ = (word_pattern >>  0) & 0xff;
    *current_ptr_byte++ = (word_pattern >>  8) & 0xff;
    *current_ptr_byte++ = (word_pattern >> 16) & 0xff;
    *current_ptr_byte++ = (word_pattern >> 24) & 0xff;
    temp = (word_pattern << 5) | (word_pattern >> 27);
    word_pattern = temp + 0x33557799;
    count = count - 4;
  }while(count > 0);
  
  current_ptr_word = (alt_u32 *)(mem_test->base_address);
  count = (mem_test->span_in_bytes) >> 2;
  word_pattern = 0x33557799;
  
  do
  {
    mem_data = *current_ptr_word++;
    if(mem_data != word_pattern)
    {
      mem_test->result = 1;
      mem_test->failing_address = (alt_u32)(--current_ptr_word);
      mem_test->expected_data = word_pattern;
      mem_test->actual_data = mem_data;
      return 1;
    }
    temp = (word_pattern << 5) | (word_pattern >> 27);
    word_pattern = temp + 0x33557799;
    count--;
  }while(count > 0);
  
  mem_test->result = 0;
  return 0;
}
