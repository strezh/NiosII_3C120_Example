#include "stdio.h"

#include "mem_test.h"
#include "system.h"
#include <sys/alt_cache.h>
#include <sys/alt_timestamp.h>
#include <sys/alt_irq.h>

/*

walking one on data bus
walking zero on data bus
walking one on address bus
walking zero on address bus

thash data bus with 0 and F
thash data bus with 5 and A
thash address bus with 0 and F
thash address bus with 5 and A

Thrash address and data bus with 0 and F
Thrash address and data bus with 5 and A

Address uniqueness, words, short, char.
Word write, short and char read. other.

*/

alt_u32 address_uniqueness_word(MEM_TEST_STRUCT *mem_test);
alt_u32 address_uniqueness_half(MEM_TEST_STRUCT *mem_test);
alt_u32 address_uniqueness_byte(MEM_TEST_STRUCT *mem_test);
alt_u32 address_uniqueness_byte_word(MEM_TEST_STRUCT *mem_test);
alt_u32 address_uniqueness_word_byte(MEM_TEST_STRUCT *mem_test);
alt_u32 databus_walking_one_word(MEM_TEST_STRUCT *mem_test);
alt_u32 databus_walking_zero_word(MEM_TEST_STRUCT *mem_test);
alt_u32 databus_thrash_00_FF_word(MEM_TEST_STRUCT *mem_test);
alt_u32 databus_thrash_55_AA_word(MEM_TEST_STRUCT *mem_test);
alt_u32 addressbus_walking_one_word(MEM_TEST_STRUCT *mem_test);
alt_u32 addressbus_walking_zero_word(MEM_TEST_STRUCT *mem_test);

#define LO_LAT_MB_SPAN	(127)
unsigned char __attribute__((aligned(4))) LO_LAT_TEST_ARRAY[LO_LAT_MB_SPAN*1024*1024];

#define HI_LAT_MB_SPAN	(128)
#define HI_LAT_TEST_ARRAY DDR2_HI_LATENCY_128M_BASE

alt_u32 HIST[256];

MEM_TEST_STRUCT mem_test;

int main()
{
  alt_u32 result;
  //int i;
  //int j;
  //int _2repeatt, _3repeatt, _4repeatt;
  alt_u32 time_stamp;
  alt_irq_context irq_context;
  
  printf("Beginning Lo Latency Memory Tests...\n");
  
  printf("Test beginning -  cached address uniqueness word...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY));
  mem_test.span_in_bytes = (LO_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("cached address uniqueness word test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");

  printf("Test beginning -  address uniqueness word...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (LO_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("address uniqueness word test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");

  printf("Test beginning -  address uniqueness half...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (LO_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_half(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("address uniqueness half test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  address uniqueness byte...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (LO_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_byte(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("address uniqueness byte test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  address uniqueness word byte...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (LO_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_word_byte(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("address uniqueness word byte test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  address uniqueness byte word...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (LO_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_byte_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("address uniqueness byte word test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  databus_walking_one_word...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (LO_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = databus_walking_one_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("databus_walking_one_word took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  databus_walking_zero_word...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (LO_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = databus_walking_zero_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("databus_walking_zero_word took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  databus_thrash_00_FF_word...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (LO_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = databus_thrash_00_FF_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("databus_thrash_00_FF_word took %lu clocks...\n", time_stamp);

  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  databus_thrash_55_AA_word...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (LO_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = databus_thrash_55_AA_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("databus_thrash_55_AA_word took %lu clocks...\n", time_stamp);

  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");

  printf("Test beginning -  addressbus_walking_one_word...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.base_address += 512*1024;
  mem_test.base_address &= ((512*1024)-1)^0xFFFFFFFF;
  mem_test.span_in_bytes = (512*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = addressbus_walking_one_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("addressbus_walking_one_word took %lu clocks...\n", time_stamp);

  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");

  printf("Test beginning -  addressbus_walking_zero_word...\n");

  mem_test.base_address = ((alt_u32)(LO_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.base_address += 512*1024;
  mem_test.base_address &= ((512*1024)-1)^0xFFFFFFFF;
  mem_test.span_in_bytes = (512*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = addressbus_walking_zero_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("addressbus_walking_zero_word took %lu clocks...\n", time_stamp);

  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Beginning Hi Latency Memory Tests...\n");
  
  printf("Test beginning -  cached address uniqueness word...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY));
  mem_test.span_in_bytes = (HI_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("cached address uniqueness word test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");

  printf("Test beginning -  address uniqueness word...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (HI_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("address uniqueness word test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");

  printf("Test beginning -  address uniqueness half...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (HI_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_half(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("address uniqueness half test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  address uniqueness byte...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (HI_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_byte(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("address uniqueness byte test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  address uniqueness word byte...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (HI_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_word_byte(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("address uniqueness word byte test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  address uniqueness byte word...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (HI_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = address_uniqueness_byte_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("address uniqueness byte word test took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  databus_walking_one_word...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (HI_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = databus_walking_one_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("databus_walking_one_word took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  databus_walking_zero_word...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (HI_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = databus_walking_zero_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("databus_walking_zero_word took %lu clocks...\n", time_stamp);
  
  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  databus_thrash_00_FF_word...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (HI_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = databus_thrash_00_FF_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("databus_thrash_00_FF_word took %lu clocks...\n", time_stamp);

  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("Test beginning -  databus_thrash_55_AA_word...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.span_in_bytes = (HI_LAT_MB_SPAN*1024*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = databus_thrash_55_AA_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("databus_thrash_55_AA_word took %lu clocks...\n", time_stamp);

  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");

  printf("Test beginning -  addressbus_walking_one_word...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.base_address += 512*1024;
  mem_test.base_address &= ((512*1024)-1)^0xFFFFFFFF;
  mem_test.span_in_bytes = (512*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = addressbus_walking_one_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("addressbus_walking_one_word took %lu clocks...\n", time_stamp);

  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");

  printf("Test beginning -  addressbus_walking_zero_word...\n");

  mem_test.base_address = ((alt_u32)(HI_LAT_TEST_ARRAY) | 0x80000000);
  mem_test.base_address += 512*1024;
  mem_test.base_address &= ((512*1024)-1)^0xFFFFFFFF;
  mem_test.span_in_bytes = (512*1024);
  mem_test.result = 0;
  
  irq_context = alt_irq_disable_all();
  alt_dcache_flush_all();
  alt_timestamp_start();
  result = addressbus_walking_zero_word(&mem_test);
  time_stamp = alt_timestamp();
  alt_irq_enable_all(irq_context);
  printf("addressbus_walking_zero_word took %lu clocks...\n", time_stamp);

  if(result != 0)
  {
	printf("---- TEST FAILURE ----\n");
    printf("failing_address = 0x%08lX\n", mem_test.failing_address);
    printf("  expected_data = 0x%08lX\n", mem_test.expected_data);
    printf("    actual_data = 0x%08lX\n", mem_test.actual_data);
  }

  printf("Test complete...\n");
  
  printf("ALL TESTS COMPLETE\n");
  
  return 0;
}
